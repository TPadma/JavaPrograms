package mgait.Dao;

import java.sql.Timestamp;
import java.util.ArrayList;

import mgait.Model.*;

public interface ParkedVehicleDao {

	public int findNearestSlot(String Vehicletype);
	public int findVehicle(String regNo);
	public boolean updateSlot(int slotId);
	public ArrayList<Integer> getAvailSlots();
	public void allocateSlot(Vehicle vehicle, int slot_id, Timestamp t);

}
