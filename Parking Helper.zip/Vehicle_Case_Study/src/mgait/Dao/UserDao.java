package mgait.Dao;

import mgait.Model.*;

public interface UserDao {

	public boolean addUsers(Users u);
	//public Users removeUser(int userId);
	public Users getUser(int userId);
}
