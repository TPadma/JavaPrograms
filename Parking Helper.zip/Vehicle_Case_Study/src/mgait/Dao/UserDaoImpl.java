package mgait.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import mgait.Model.*;

public class UserDaoImpl implements UserDao {

	Connection con = DbUtil.getConnection();
	@Override
	public boolean addUsers(Users u) {

		Users us =new Users(u.getUserName(),u.getPassword(),u.getUserRole(),u.getUserId());
		String s = "Insert into USERS(USER_ID,PASSWORD,USER_ROLE,USER_NAME) VALUES(?,?,?,?)";
		int rows=0;
		try {
			PreparedStatement ps=con.prepareStatement(s);
			ps.setInt(1, us.getUserId());
			ps.setString(2,us.getPassword());
			ps.setString(3,us.getUserRole());
			ps.setString(4,us.getUserName());
			rows=ps.executeUpdate();	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rows!=0)
			return true;
		else
			return false;

	}

	@Override
	public  Users getUser(int userId) {

		Users u=null;
		String sql="Select * from Users where user_id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,userId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{

				u=new Users();
				u.setUserName(rs.getString("USER_NAME"));
				u.setPassword(rs.getString("PASSWORD"));
				u.setUserRole(rs.getString("USER_ROLE"));
				u.setUserId(rs.getInt("USER_ID"));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

}
