package mgait.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.http.HttpSession;

import mgait.Model.*;
import mgait.Controller.*;

public class ParkedVehicleDaoImpl implements ParkedVehicleDao {

	Connection con = DbUtil.getConnection();

	Vehicle vehicleObj;
	ParkedVehicle parkedVehicleObj;
	@Override
	public int findNearestSlot(String Vehicletype) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int findVehicle(String regNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void allocateSlot(Vehicle vehicle,int slot_id,Timestamp t) {
		
		try{

			String s = "UPDATE PARKING_TABLE SET VEHICLE_REG_NO=?, OWNER_MOBILE=?, ENTRY_TIME='?' WHERE SLOT_ID=?";
			PreparedStatement es = con.prepareStatement(s);
			es.setString(1, vehicle.getRegNo());
			es.setLong(2, vehicle.getOwnerMobile());
			es.setTimestamp(3, t);
			es.setInt(4, slot_id);
			
			es.executeUpdate();
			

			}catch(SQLException e)
			{
			e.printStackTrace();
			}

		
	}

	@Override
	public boolean updateSlot(int slotId) {
		return false;
	}


	ArrayList<Integer> slotIds = new ArrayList<Integer>();
	@Override
	public ArrayList<Integer> getAvailSlots() 
	{
		
		try{
			String s = "SELECT SLOT_ID,SLOT_TYPE FROM PARKING_TABLE WHERE VEHICLE_REG_NO IS NULL OR VEHICLE_REG_NO = ''";
			Statement es = con.createStatement();
			ResultSet rs = es.executeQuery(s);
			while(rs.next())
			{

				slotIds.add(rs.getInt("SLOT_ID"));
			}

			}catch(SQLException e)
			{
			e.printStackTrace();
			}

		return slotIds;

	}
}
