package mgait.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {

	private static  String DB_USER = "jdbc:oracle:thin:@localhost:1521:XE";
	private static  String USER_ID = "PADMA";
	private static  String PWD = "LO1984dj";
	private static  String Driver_Name="oracle.jdbc.OracleDriver";
	static Connection conn=null;
	
	public static Connection getConnection() {
		try{
		Class.forName(Driver_Name);
		conn=DriverManager.getConnection(DB_USER,USER_ID,PWD);
		}catch(ClassNotFoundException|SQLException e)
		{
			e.printStackTrace();
		}
		return conn;
		
	}
	public static void closeConnection(Connection conn) throws SQLException
	{
		
		conn.close();
	}
	
}
