package mgait.Model;

import java.sql.Timestamp;

public class ParkedVehicle {

	private Vehicle vehicle;
	private int slot_id;
	private java.sql.Timestamp entryTime;
	
	public ParkedVehicle(Vehicle vehicle, int slotId, Timestamp entryTime) {
		super();
		this.vehicle = vehicle;
		this.slot_id = slotId;
		this.entryTime = entryTime;
	}
	
	public Vehicle getVehicle() {
		return vehicle;
	}
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public int getSlotId() {
		return slot_id;
	}
	public void setSlot_id(int slotId) {
		this.slot_id = slotId;
	}
	public java.sql.Timestamp getEntryTime() {
		return entryTime;
	}
	public void setEntryTime(java.sql.Timestamp entryTime) {
		this.entryTime = entryTime;
	}
	
	
}
