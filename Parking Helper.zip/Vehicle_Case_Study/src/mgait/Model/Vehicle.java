package mgait.Model;

public class Vehicle {

	private String regNo;
	private String Vehicletype;
	private long ownerMobile;
	public String getRegNo() {
		return regNo;
	}
	
	public Vehicle(){}
	public Vehicle(String regNo, String vehicletype, long ownerMobile) {
		super();
		this.regNo = regNo;
		Vehicletype = vehicletype;
		this.ownerMobile = ownerMobile;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public String getVehicletype() {
		return Vehicletype;
	}
	public void setVehicletype(String vehicletype) {
		Vehicletype = vehicletype;
	}
	public long getOwnerMobile() {
		return ownerMobile;
	}
	public void setOwnerMobile(long ownerMobile) {
		this.ownerMobile = ownerMobile;
	}
}
