package mgait.Model;

public class Users {

	private String userName;
	private String password;
	private String userRole;
	private int userId;
	public Users(String userName, String password, String userRole,
			int userId) {
		super();
		this.userName = userName;
		this.password = password;
		this.userRole = userRole;
		this.userId = userId;
	}
	public Users() {
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
