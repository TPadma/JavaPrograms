package mgait.Model;

import java.sql.Timestamp;

public class ExitedVehicle {

	private ParkedVehicle exitVehicle;
	private java.sql.Timestamp exitTime;
	private int billAmount;
	public ParkedVehicle getExitVehicle() {
		return exitVehicle;
	}
	public void setExitVehicle(ParkedVehicle exitVehicle) {
		this.exitVehicle = exitVehicle;
	}
	public java.sql.Timestamp getExitTime() {
		return exitTime;
	}
	public void setExitTime(java.sql.Timestamp exitTime) {
		this.exitTime = exitTime;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public ExitedVehicle(ParkedVehicle exitVehicle, Timestamp exitTime,
			int billAmount) {
		super();
		this.exitVehicle = exitVehicle;
		this.exitTime = exitTime;
		this.billAmount = billAmount;
	}
}
