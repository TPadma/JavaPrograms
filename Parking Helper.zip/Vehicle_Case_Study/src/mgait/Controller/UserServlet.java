package mgait.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mgait.Dao.*;
import mgait.Model.*;



@WebServlet("/userServlet")
public class UserServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {

		Users u=null;
		UserDaoImpl ud=new UserDaoImpl();
		String name=request.getParameter("username");
		String password=request.getParameter("password");
		int userid=Integer.parseInt(request.getParameter("userid"));
		String userrole=request.getParameter("userrole");
		PrintWriter out=response.getWriter();
		u=ud.getUser(userid);
		if(u!=null && u.getPassword().equals(password) && userrole.equals("admin") && userid==100)
		{
			response.setContentType("text/html");
			RequestDispatcher dis1=request.getRequestDispatcher("/AdminFirstPage.jsp");
			dis1.forward(request, response);				

		}
		else if(u!=null && u.getPassword().equals(password))
		{
			response.setContentType("text/html");
			RequestDispatcher dis1=request.getRequestDispatcher("/UserFirstPage.jsp");
			dis1.forward(request, response);	

		}
		else
		{
			response.setContentType("text/html");
			RequestDispatcher dis1=request.getRequestDispatcher("/Login.jsp");
			dis1.include(request, response);		
			out.println("Invalid Password");	
			out.println("<h3>New user Please Register<h3>");
		}
	}

}

