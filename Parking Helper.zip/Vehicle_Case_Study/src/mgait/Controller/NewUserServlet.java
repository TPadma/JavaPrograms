package mgait.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mgait.Dao.UserDaoImpl;
import mgait.Model.*;

@WebServlet("/newUserServlet")
public class NewUserServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		Users u=null;
		UserDaoImpl ud=new UserDaoImpl();
		String name=request.getParameter("name");
		String password=request.getParameter("pwd1");
		String password1=request.getParameter("pwd2");
		String userrole=request.getParameter("userrole");
		int userid=Integer.parseInt(request.getParameter("userid"));
		
		PrintWriter out=response.getWriter();
		if(password.equals(password1))
		{
			
			u=new Users(name,password,userrole,userid);
			ud.addUsers(u);
			RequestDispatcher dis=request.getRequestDispatcher("NewUser.jsp");
			dis.include(request, response);
			out.println("<h2 style='color:black;background-color:blue;width:110px'>Registered<h2>");
			out.println("<a href='Login.jsp' style='color:yellow'>Back to Login</a>");

		}
		else
		{
			RequestDispatcher dis=request.getRequestDispatcher("NewUser.jsp");
			dis.include(request, response);
			out.println("Password should be same");

		}

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
	}


}
