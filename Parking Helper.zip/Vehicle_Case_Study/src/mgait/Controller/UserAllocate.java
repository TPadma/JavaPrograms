package mgait.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mgait.Dao.*;
import mgait.Model.*;


@WebServlet("/UserAllocate")
public class UserAllocate extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		ParkedVehicleDaoImpl pv = new ParkedVehicleDaoImpl();
		ArrayList<Integer> slotsavail = pv.getAvailSlots();
		HttpSession session = req.getSession();
		session.setAttribute("slotlist", slotsavail);//available slot list
		RequestDispatcher dispatch = req.getRequestDispatcher("UserAllocate.jsp");
		dispatch.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		doPost(req, resp);
	}
	
}
