package mgait.Controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import mgait.Dao.ParkedVehicleDaoImpl;
import mgait.Model.ParkedVehicle;
import mgait.Model.Vehicle;

@WebServlet("/AllocateSlot")
public class AllocateSlot extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String Vehicletype;
		Calendar c = Calendar.getInstance();
		Timestamp t = new Timestamp(c.getTimeInMillis());
		HttpSession session = request.getSession();
		String vehicleRegNo= request.getParameter("vehicleRegNo");
		int mobileNu=  Integer.parseInt(request.getParameter("mobileNum"));
		if(Integer.parseInt(request.getParameter("slot"))>200)
		{
			Vehicletype = "two_wheeler";
		}
		else
		{
			Vehicletype = "four_wheeler";
		}
		Vehicle vehicle = new Vehicle(vehicleRegNo, Vehicletype, mobileNu);
		ParkedVehicleDaoImpl pvi = new ParkedVehicleDaoImpl();
		ParkedVehicle pv = new ParkedVehicle(vehicle,(int)session.getAttribute("slot") ,t);
		pvi.allocateSlot(vehicle,(int)session.getAttribute("slot"),t);
		RequestDispatcher dispatch = request.getRequestDispatcher("GenerateTicket.jsp");
		dispatch.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
